package com.vehiclerental.model;

import java.math.BigDecimal;

public class Vehicle {
    private int id;
    private String name;
    private String type;
    private BigDecimal rentPerDay;
    private String status;

    public Vehicle() {}

    public Vehicle(int id, String name, String type, BigDecimal rentPerDay, String status) {
        this.id = id;
        this.name = name;
        this.type = type;
        this.rentPerDay = rentPerDay;
        this.status = status;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
    
    public BigDecimal getRentPerDay() { return rentPerDay; }
    public void setRentPerDay(BigDecimal rentPerDay) { this.rentPerDay = rentPerDay; }
    
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    @Override
    public String toString() {
        return name + " (" + type + ")";
    }
}
