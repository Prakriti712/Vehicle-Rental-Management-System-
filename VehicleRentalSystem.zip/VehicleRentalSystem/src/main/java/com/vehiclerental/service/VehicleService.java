package com.vehiclerental.service;

import com.vehiclerental.dao.VehicleDAO;
import com.vehiclerental.model.Vehicle;

import java.math.BigDecimal;
import java.util.List;

public class VehicleService {
    private final VehicleDAO vehicleDAO;

    public VehicleService() {
        this.vehicleDAO = new VehicleDAO();
    }

    public List<Vehicle> getAllVehicles() {
        return vehicleDAO.getAllVehicles();
    }

    public List<Vehicle> getAvailableVehicles() {
        return vehicleDAO.getAvailableVehicles();
    }

    public boolean addVehicle(String name, String type, BigDecimal rentPerDay) {
        Vehicle vehicle = new Vehicle(0, name, type, rentPerDay, "AVAILABLE");
        return vehicleDAO.addVehicle(vehicle);
    }

    public boolean updateVehicle(int id, String name, String type, BigDecimal rentPerDay, String status) {
        Vehicle vehicle = new Vehicle(id, name, type, rentPerDay, status);
        return vehicleDAO.updateVehicle(vehicle);
    }

    public boolean deleteVehicle(int id) {
        return vehicleDAO.deleteVehicle(id);
    }
}
