package com.vehiclerental.service;

import com.vehiclerental.dao.RentalDAO;
import com.vehiclerental.dao.VehicleDAO;
import com.vehiclerental.model.Rental;
import com.vehiclerental.model.Vehicle;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

public class RentalService {
    private final RentalDAO rentalDAO;
    private final VehicleDAO vehicleDAO;

    public RentalService() {
        this.rentalDAO = new RentalDAO();
        this.vehicleDAO = new VehicleDAO();
    }

    public BigDecimal calculateCost(BigDecimal rentPerDay, LocalDate startDate, LocalDate endDate) {
        long days = ChronoUnit.DAYS.between(startDate, endDate);
        if (days == 0) days = 1; // Minimum 1 day rent
        return rentPerDay.multiply(BigDecimal.valueOf(days));
    }

    public boolean bookVehicle(int userId, Vehicle vehicle, LocalDate startDate, LocalDate endDate) {
        BigDecimal totalCost = calculateCost(vehicle.getRentPerDay(), startDate, endDate);
        
        Rental rental = new Rental(0, userId, vehicle.getId(), startDate, endDate, totalCost, "ACTIVE");
        
        if (rentalDAO.addRental(rental)) {
            return vehicleDAO.updateVehicleStatus(vehicle.getId(), "RENTED");
        }
        return false;
    }

    public List<Rental> getCustomerRentals(int userId) {
        return rentalDAO.getRentalsByUserId(userId);
    }

    public List<Rental> getAllRentals() {
        return rentalDAO.getAllRentals();
    }

    public boolean returnVehicle(int rentalId) {
        Rental rental = rentalDAO.getRentalById(rentalId);
        if (rental != null && "ACTIVE".equals(rental.getStatus())) {
            if (rentalDAO.updateRentalStatus(rentalId, "COMPLETED")) {
                return vehicleDAO.updateVehicleStatus(rental.getVehicleId(), "AVAILABLE");
            }
        }
        return false;
    }
}
