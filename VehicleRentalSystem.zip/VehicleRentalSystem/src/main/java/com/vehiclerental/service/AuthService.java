package com.vehiclerental.service;

import com.vehiclerental.dao.UserDAO;
import com.vehiclerental.model.User;
import com.vehiclerental.util.PasswordUtil;
import com.vehiclerental.util.SessionManager;

public class AuthService {
    private final UserDAO userDAO;

    public AuthService() {
        this.userDAO = new UserDAO();
    }

    public boolean login(String username, String password) {
        User user = userDAO.getUserByUsername(username);
        if (user != null) {
            String hashedInput = PasswordUtil.hashPassword(password);
            if (hashedInput.equals(user.getPasswordHash())) {
                SessionManager.setCurrentUser(user);
                return true;
            }
        }
        return false;
    }

    public boolean register(String username, String password, String role, String fullName, String contactInfo) {
        if (userDAO.getUserByUsername(username) != null) {
            return false; // User already exists
        }
        
        String hashedPass = PasswordUtil.hashPassword(password);
        User newUser = new User(0, username, hashedPass, role, fullName, contactInfo);
        return userDAO.registerUser(newUser);
    }
}
