package com.vehiclerental.dao;

import com.vehiclerental.model.Rental;
import com.vehiclerental.util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class RentalDAO {

    public boolean addRental(Rental rental) {
        String query = "INSERT INTO Rentals (user_id, vehicle_id, start_date, end_date, total_cost, status) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setInt(1, rental.getUserId());
            stmt.setInt(2, rental.getVehicleId());
            stmt.setDate(3, Date.valueOf(rental.getStartDate()));
            stmt.setDate(4, Date.valueOf(rental.getEndDate()));
            stmt.setBigDecimal(5, rental.getTotalCost());
            stmt.setString(6, rental.getStatus());
            
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public List<Rental> getRentalsByUserId(int userId) {
        List<Rental> rentals = new ArrayList<>();
        String query = "SELECT r.*, v.name as vehicle_name FROM Rentals r " +
                       "JOIN Vehicles v ON r.vehicle_id = v.id WHERE r.user_id = ? ORDER BY r.start_date DESC";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setInt(1, userId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Rental rental = mapResultSetToRental(rs);
                    rental.setVehicleName(rs.getString("vehicle_name"));
                    rentals.add(rental);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rentals;
    }
    
    public List<Rental> getAllRentals() {
        List<Rental> rentals = new ArrayList<>();
        String query = "SELECT r.*, v.name as vehicle_name, u.username as user_name FROM Rentals r " +
                       "JOIN Vehicles v ON r.vehicle_id = v.id " +
                       "JOIN Users u ON r.user_id = u.id ORDER BY r.start_date DESC";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            while (rs.next()) {
                Rental rental = mapResultSetToRental(rs);
                rental.setVehicleName(rs.getString("vehicle_name"));
                rental.setUserName(rs.getString("user_name"));
                rentals.add(rental);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rentals;
    }
    
    public boolean updateRentalStatus(int rentalId, String status) {
        String query = "UPDATE Rentals SET status = ? WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setString(1, status);
            stmt.setInt(2, rentalId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public Rental getRentalById(int rentalId) {
        String query = "SELECT * FROM Rentals WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, rentalId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToRental(rs);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    private Rental mapResultSetToRental(ResultSet rs) throws SQLException {
        return new Rental(
            rs.getInt("id"),
            rs.getInt("user_id"),
            rs.getInt("vehicle_id"),
            rs.getDate("start_date").toLocalDate(),
            rs.getDate("end_date").toLocalDate(),
            rs.getBigDecimal("total_cost"),
            rs.getString("status")
        );
    }
}
