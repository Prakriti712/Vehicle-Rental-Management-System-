package com.vehiclerental.ui.panels.customer;

import com.vehiclerental.model.Rental;
import com.vehiclerental.service.RentalService;
import com.vehiclerental.ui.components.RoundedButton;
import com.vehiclerental.ui.components.Theme;
import com.vehiclerental.util.SessionManager;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class CustomerRentalsPanel extends JPanel {

    private final RentalService rentalService;
    private JTable table;
    private DefaultTableModel tableModel;

    public CustomerRentalsPanel(RentalService rentalService) {
        this.rentalService = rentalService;
        setLayout(new BorderLayout(20, 20));
        setBackground(Theme.BACKGROUND_DARK);
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        initUI();
    }

    private void initUI() {
        JLabel header = new JLabel("My Rental History");
        header.setFont(Theme.FONT_TITLE);
        header.setForeground(Theme.TEXT_LIGHT);
        add(header, BorderLayout.NORTH);

        String[] columns = {"Rental ID", "Vehicle", "Start Date", "End Date", "Total Cost", "Status"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        table = new JTable(tableModel);
        table.setRowHeight(30);
        table.setFont(Theme.FONT_REGULAR);
        table.getTableHeader().setFont(Theme.FONT_BOLD);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        actionPanel.setBackground(Theme.BACKGROUND_DARK);

        RoundedButton refreshBtn = new RoundedButton("Refresh", Theme.PRIMARY, Theme.PRIMARY_HOVER);
        refreshBtn.setPreferredSize(new Dimension(120, 35));
        refreshBtn.addActionListener(e -> loadRentals());

        actionPanel.add(refreshBtn);
        add(actionPanel, BorderLayout.SOUTH);
    }

    public void loadRentals() {
        tableModel.setRowCount(0);
        if (SessionManager.getCurrentUser() != null) {
            int userId = SessionManager.getCurrentUser().getId();
            List<Rental> rentals = rentalService.getCustomerRentals(userId);
            for (Rental r : rentals) {
                tableModel.addRow(new Object[]{
                    r.getId(), r.getVehicleName(), r.getStartDate(), r.getEndDate(), r.getTotalCost(), r.getStatus()
                });
            }
        }
    }
}
