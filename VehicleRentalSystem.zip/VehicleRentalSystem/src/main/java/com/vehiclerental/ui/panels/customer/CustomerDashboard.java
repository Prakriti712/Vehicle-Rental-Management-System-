package com.vehiclerental.ui.panels.customer;

import com.vehiclerental.service.RentalService;
import com.vehiclerental.service.VehicleService;
import com.vehiclerental.ui.components.RoundedButton;
import com.vehiclerental.ui.components.Theme;
import com.vehiclerental.util.SessionManager;

import javax.swing.*;
import java.awt.*;

public class CustomerDashboard extends JPanel {

    private final VehicleService vehicleService;
    private final RentalService rentalService;
    private final Runnable onLogout;
    
    private JPanel contentPanel;
    private CardLayout cardLayout;
    
    private BrowseVehiclesPanel browseVehiclesPanel;
    private CustomerRentalsPanel customerRentalsPanel;

    public CustomerDashboard(VehicleService vehicleService, RentalService rentalService, Runnable onLogout) {
        this.vehicleService = vehicleService;
        this.rentalService = rentalService;
        this.onLogout = onLogout;
        
        setLayout(new BorderLayout());
        setBackground(Theme.BACKGROUND_DARK);
        
        initSidebar();
        initContentArea();
    }

    private void initSidebar() {
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(Theme.PANEL_DARK);
        sidebar.setPreferredSize(new Dimension(220, 0));
        sidebar.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 10));

        JLabel titleLabel = new JLabel("Welcome, " + (SessionManager.getCurrentUser() != null ? SessionManager.getCurrentUser().getFullName() : "Customer"));
        titleLabel.setFont(Theme.FONT_HEADER);
        titleLabel.setForeground(Theme.PRIMARY);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        sidebar.add(titleLabel);
        
        sidebar.add(Box.createRigidArea(new Dimension(0, 40)));

        RoundedButton browseBtn = new RoundedButton("Browse Vehicles", Theme.PRIMARY, Theme.PRIMARY_HOVER);
        browseBtn.setMaximumSize(new Dimension(200, 40));
        browseBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        browseBtn.addActionListener(e -> {
            browseVehiclesPanel.loadVehicles(); // Refresh before showing
            cardLayout.show(contentPanel, "BROWSE");
        });
        sidebar.add(browseBtn);
        
        sidebar.add(Box.createRigidArea(new Dimension(0, 15)));

        RoundedButton historyBtn = new RoundedButton("Rental History", Theme.SECONDARY, Theme.PRIMARY_HOVER);
        historyBtn.setMaximumSize(new Dimension(200, 40));
        historyBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        historyBtn.addActionListener(e -> {
            customerRentalsPanel.loadRentals(); // Refresh before showing
            cardLayout.show(contentPanel, "HISTORY");
        });
        sidebar.add(historyBtn);

        sidebar.add(Box.createVerticalGlue());

        RoundedButton logoutBtn = new RoundedButton("Logout", Theme.DANGER, Theme.DANGER.brighter());
        logoutBtn.setMaximumSize(new Dimension(200, 40));
        logoutBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        logoutBtn.addActionListener(e -> {
            SessionManager.logout();
            onLogout.run();
        });
        sidebar.add(logoutBtn);

        add(sidebar, BorderLayout.WEST);
    }

    private void initContentArea() {
        cardLayout = new CardLayout();
        contentPanel = new JPanel(cardLayout);
        contentPanel.setBackground(Theme.BACKGROUND_DARK);

        browseVehiclesPanel = new BrowseVehiclesPanel(vehicleService, rentalService);
        customerRentalsPanel = new CustomerRentalsPanel(rentalService);

        contentPanel.add(browseVehiclesPanel, "BROWSE");
        contentPanel.add(customerRentalsPanel, "HISTORY");

        add(contentPanel, BorderLayout.CENTER);
    }
}
