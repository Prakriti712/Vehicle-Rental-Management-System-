package com.vehiclerental.ui;

import com.vehiclerental.service.AuthService;
import com.vehiclerental.service.RentalService;
import com.vehiclerental.service.VehicleService;
import com.vehiclerental.ui.panels.admin.AdminDashboard;
import com.vehiclerental.ui.panels.auth.LoginPanel;
import com.vehiclerental.ui.panels.auth.RegisterPanel;
import com.vehiclerental.ui.panels.customer.CustomerDashboard;
import com.vehiclerental.util.SessionManager;

import javax.swing.*;
import java.awt.*;

public class MainFrame extends JFrame {

    private AuthService authService;
    private VehicleService vehicleService;
    private RentalService rentalService;
    
    private CardLayout cardLayout;
    private JPanel mainPanel;

    public MainFrame() {
        super("Vehicle Rental System");
        
        // Initialize Services
        authService = new AuthService();
        vehicleService = new VehicleService();
        rentalService = new RentalService();
        
        initUI();
    }

    private void initUI() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 700);
        setLocationRelativeTo(null);
        
        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);
        
        // Add Auth Panels
        LoginPanel loginPanel = new LoginPanel(authService, this::onLoginSuccess, this::showRegister);
        RegisterPanel registerPanel = new RegisterPanel(authService, this::showLogin, this::showLogin);
        
        mainPanel.add(loginPanel, "LOGIN");
        mainPanel.add(registerPanel, "REGISTER");

        add(mainPanel);
    }
    
    private void showLogin() {
        cardLayout.show(mainPanel, "LOGIN");
    }

    private void showRegister() {
        cardLayout.show(mainPanel, "REGISTER");
    }

    private void onLoginSuccess() {
        // Build dashboards lazily to ensure they reflect fresh data and the current user
        if (SessionManager.isAdmin()) {
            AdminDashboard adminDashboard = new AdminDashboard(vehicleService, rentalService, this::showLogin);
            mainPanel.add(adminDashboard, "ADMIN_DASHBOARD");
            cardLayout.show(mainPanel, "ADMIN_DASHBOARD");
        } else {
            CustomerDashboard customerDashboard = new CustomerDashboard(vehicleService, rentalService, this::showLogin);
            mainPanel.add(customerDashboard, "CUSTOMER_DASHBOARD");
            cardLayout.show(mainPanel, "CUSTOMER_DASHBOARD");
        }
    }
}
