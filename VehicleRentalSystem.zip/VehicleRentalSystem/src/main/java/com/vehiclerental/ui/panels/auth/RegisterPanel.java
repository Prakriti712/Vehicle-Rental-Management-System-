package com.vehiclerental.ui.panels.auth;

import com.vehiclerental.service.AuthService;
import com.vehiclerental.ui.components.RoundedButton;
import com.vehiclerental.ui.components.StyledPasswordField;
import com.vehiclerental.ui.components.StyledTextField;
import com.vehiclerental.ui.components.Theme;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class RegisterPanel extends JPanel {

    private AuthService authService;
    private StyledTextField userField;
    private StyledPasswordField passField;
    private StyledTextField nameField;
    private StyledTextField contactField;
    private JLabel messageLabel;

    private Runnable onRegisterSuccess;
    private Runnable onGoToLogin;

    public RegisterPanel(AuthService authService, Runnable onRegisterSuccess, Runnable onGoToLogin) {
        this.authService = authService;
        this.onRegisterSuccess = onRegisterSuccess;
        this.onGoToLogin = onGoToLogin;
        
        setBackground(Theme.BACKGROUND_DARK);
        setLayout(new GridBagLayout());
        
        initUI();
    }

    private void initUI() {
        JPanel formPanel = new JPanel();
        formPanel.setBackground(Theme.PANEL_DARK);
        formPanel.setLayout(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createEmptyBorder(40, 40, 40, 40));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 10, 5, 10);
        gbc.gridx = 0;
        gbc.gridy = 0;
        
        JLabel titleLabel = new JLabel("Create Account");
        titleLabel.setFont(Theme.FONT_TITLE);
        titleLabel.setForeground(Theme.TEXT_LIGHT);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        formPanel.add(titleLabel, gbc);

        gbc.gridy++;
        JLabel nameLabel = new JLabel("Full Name:");
        nameLabel.setFont(Theme.FONT_REGULAR);
        nameLabel.setForeground(Theme.TEXT_MUTED);
        formPanel.add(nameLabel, gbc);

        gbc.gridy++;
        nameField = new StyledTextField(20);
        formPanel.add(nameField, gbc);
        
        gbc.gridy++;
        JLabel userLabel = new JLabel("Username:");
        userLabel.setFont(Theme.FONT_REGULAR);
        userLabel.setForeground(Theme.TEXT_MUTED);
        formPanel.add(userLabel, gbc);

        gbc.gridy++;
        userField = new StyledTextField(20);
        formPanel.add(userField, gbc);

        gbc.gridy++;
        JLabel passLabel = new JLabel("Password:");
        passLabel.setFont(Theme.FONT_REGULAR);
        passLabel.setForeground(Theme.TEXT_MUTED);
        formPanel.add(passLabel, gbc);

        gbc.gridy++;
        passField = new StyledPasswordField(20);
        formPanel.add(passField, gbc);
        
        gbc.gridy++;
        JLabel contactLabel = new JLabel("Contact Info:");
        contactLabel.setFont(Theme.FONT_REGULAR);
        contactLabel.setForeground(Theme.TEXT_MUTED);
        formPanel.add(contactLabel, gbc);

        gbc.gridy++;
        contactField = new StyledTextField(20);
        formPanel.add(contactField, gbc);

        gbc.gridy++;
        messageLabel = new JLabel("");
        messageLabel.setForeground(Theme.DANGER);
        messageLabel.setHorizontalAlignment(SwingConstants.CENTER);
        formPanel.add(messageLabel, gbc);

        gbc.gridy++;
        RoundedButton regBtn = new RoundedButton("Register", Theme.SECONDARY, Theme.PRIMARY_HOVER);
        regBtn.setPreferredSize(new Dimension(200, 40));
        regBtn.addActionListener(this::handleRegister);
        formPanel.add(regBtn, gbc);

        gbc.gridy++;
        JButton loginBtn = new JButton("Already have an account? Login");
        loginBtn.setFont(Theme.FONT_REGULAR);
        loginBtn.setForeground(Theme.PRIMARY);
        loginBtn.setContentAreaFilled(false);
        loginBtn.setBorderPainted(false);
        loginBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        loginBtn.addActionListener(e -> onGoToLogin.run());
        formPanel.add(loginBtn, gbc);

        add(formPanel);
    }

    private void handleRegister(ActionEvent e) {
        String name = nameField.getText().trim();
        String username = userField.getText().trim();
        String password = new String(passField.getPassword());
        String contact = contactField.getText().trim();
        
        if (name.isEmpty() || username.isEmpty() || password.isEmpty() || contact.isEmpty()) {
            messageLabel.setText("Please fill all fields.");
            return;
        }

        // By default, open registration is for customers
        if (authService.register(username, password, "CUSTOMER", name, contact)) {
            userField.setText("");
            passField.setText("");
            nameField.setText("");
            contactField.setText("");
            messageLabel.setText("");
            onRegisterSuccess.run();
        } else {
            messageLabel.setText("Username already exists or error occurred.");
        }
    }
}
