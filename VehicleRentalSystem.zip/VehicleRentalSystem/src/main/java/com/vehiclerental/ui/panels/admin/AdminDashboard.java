package com.vehiclerental.ui.panels.admin;

import com.vehiclerental.service.RentalService;
import com.vehiclerental.service.VehicleService;
import com.vehiclerental.ui.components.RoundedButton;
import com.vehiclerental.ui.components.Theme;
import com.vehiclerental.util.SessionManager;

import javax.swing.*;
import java.awt.*;

public class AdminDashboard extends JPanel {

    private final VehicleService vehicleService;
    private final RentalService rentalService;
    private final Runnable onLogout;
    
    private JPanel contentPanel;
    private CardLayout cardLayout;

    public AdminDashboard(VehicleService vehicleService, RentalService rentalService, Runnable onLogout) {
        this.vehicleService = vehicleService;
        this.rentalService = rentalService;
        this.onLogout = onLogout;
        
        setLayout(new BorderLayout());
        setBackground(Theme.BACKGROUND_DARK);
        
        initSidebar();
        initContentArea();
    }

    private void initSidebar() {
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(Theme.PANEL_DARK);
        sidebar.setPreferredSize(new Dimension(220, 0));
        sidebar.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 10));

        JLabel titleLabel = new JLabel("Admin Panel");
        titleLabel.setFont(Theme.FONT_TITLE);
        titleLabel.setForeground(Theme.PRIMARY);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        sidebar.add(titleLabel);
        
        sidebar.add(Box.createRigidArea(new Dimension(0, 40)));

        RoundedButton manageVehiclesBtn = new RoundedButton("Manage Vehicles", Theme.PRIMARY, Theme.PRIMARY_HOVER);
        manageVehiclesBtn.setMaximumSize(new Dimension(200, 40));
        manageVehiclesBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        manageVehiclesBtn.addActionListener(e -> cardLayout.show(contentPanel, "VEHICLES"));
        sidebar.add(manageVehiclesBtn);
        
        sidebar.add(Box.createRigidArea(new Dimension(0, 15)));

        RoundedButton viewRentalsBtn = new RoundedButton("View Rentals", Theme.SECONDARY, Theme.PRIMARY_HOVER);
        viewRentalsBtn.setMaximumSize(new Dimension(200, 40));
        viewRentalsBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        viewRentalsBtn.addActionListener(e -> cardLayout.show(contentPanel, "RENTALS"));
        sidebar.add(viewRentalsBtn);

        sidebar.add(Box.createVerticalGlue());

        RoundedButton logoutBtn = new RoundedButton("Logout", Theme.DANGER, Theme.DANGER.brighter());
        logoutBtn.setMaximumSize(new Dimension(200, 40));
        logoutBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        logoutBtn.addActionListener(e -> {
            SessionManager.logout();
            onLogout.run();
        });
        sidebar.add(logoutBtn);

        add(sidebar, BorderLayout.WEST);
    }

    private void initContentArea() {
        cardLayout = new CardLayout();
        contentPanel = new JPanel(cardLayout);
        contentPanel.setBackground(Theme.BACKGROUND_DARK);

        contentPanel.add(new ManageVehiclesPanel(vehicleService), "VEHICLES");
        contentPanel.add(new AdminRentalsPanel(rentalService), "RENTALS");

        add(contentPanel, BorderLayout.CENTER);
    }
}
