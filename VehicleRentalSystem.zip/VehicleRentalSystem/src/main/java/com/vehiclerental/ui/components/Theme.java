package com.vehiclerental.ui.components;

import java.awt.Color;
import java.awt.Font;

public class Theme {
    // Soft Dark Theme Palette
    public static final Color BACKGROUND_DARK = new Color(28, 30, 38);
    public static final Color PANEL_DARK = new Color(38, 41, 51);
    public static final Color PRIMARY = new Color(113, 92, 232); // Deep Indigo
    public static final Color PRIMARY_HOVER = new Color(133, 114, 245);
    public static final Color SECONDARY = new Color(52, 211, 153); // Emerald Green
    public static final Color DANGER = new Color(248, 113, 113); // Soft Red
    
    public static final Color TEXT_LIGHT = new Color(241, 245, 249);
    public static final Color TEXT_MUTED = new Color(148, 163, 184);
    
    public static final Font FONT_TITLE = new Font("Segoe UI", Font.BOLD, 24);
    public static final Font FONT_HEADER = new Font("Segoe UI", Font.BOLD, 18);
    public static final Font FONT_REGULAR = new Font("Segoe UI", Font.PLAIN, 14);
    public static final Font FONT_BOLD = new Font("Segoe UI", Font.BOLD, 14);
}
