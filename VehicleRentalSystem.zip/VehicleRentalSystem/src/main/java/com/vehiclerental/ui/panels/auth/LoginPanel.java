package com.vehiclerental.ui.panels.auth;

import com.vehiclerental.service.AuthService;
import com.vehiclerental.ui.components.RoundedButton;
import com.vehiclerental.ui.components.StyledPasswordField;
import com.vehiclerental.ui.components.StyledTextField;
import com.vehiclerental.ui.components.Theme;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class LoginPanel extends JPanel {

    private AuthService authService;
    private StyledTextField userField;
    private StyledPasswordField passField;
    private JLabel messageLabel;

    private Runnable onLoginSuccess;
    private Runnable onGoToRegister;

    public LoginPanel(AuthService authService, Runnable onLoginSuccess, Runnable onGoToRegister) {
        this.authService = authService;
        this.onLoginSuccess = onLoginSuccess;
        this.onGoToRegister = onGoToRegister;
        
        setBackground(Theme.BACKGROUND_DARK);
        setLayout(new GridBagLayout());
        
        initUI();
    }

    private void initUI() {
        JPanel formPanel = new JPanel();
        formPanel.setBackground(Theme.PANEL_DARK);
        formPanel.setLayout(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createEmptyBorder(40, 40, 40, 40));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.gridx = 0;
        gbc.gridy = 0;
        
        JLabel titleLabel = new JLabel("Welcome Back");
        titleLabel.setFont(Theme.FONT_TITLE);
        titleLabel.setForeground(Theme.TEXT_LIGHT);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        gbc.gridwidth = 2;
        formPanel.add(titleLabel, gbc);

        gbc.gridy++;
        gbc.gridwidth = 1;
        JLabel userLabel = new JLabel("Username:");
        userLabel.setFont(Theme.FONT_REGULAR);
        userLabel.setForeground(Theme.TEXT_MUTED);
        formPanel.add(userLabel, gbc);

        gbc.gridy++;
        userField = new StyledTextField(20);
        formPanel.add(userField, gbc);

        gbc.gridy++;
        JLabel passLabel = new JLabel("Password:");
        passLabel.setFont(Theme.FONT_REGULAR);
        passLabel.setForeground(Theme.TEXT_MUTED);
        formPanel.add(passLabel, gbc);

        gbc.gridy++;
        passField = new StyledPasswordField(20);
        formPanel.add(passField, gbc);
        
        gbc.gridy++;
        messageLabel = new JLabel("");
        messageLabel.setForeground(Theme.DANGER);
        messageLabel.setHorizontalAlignment(SwingConstants.CENTER);
        formPanel.add(messageLabel, gbc);

        gbc.gridy++;
        RoundedButton loginBtn = new RoundedButton("Login", Theme.PRIMARY, Theme.PRIMARY_HOVER);
        loginBtn.setPreferredSize(new Dimension(200, 40));
        loginBtn.addActionListener(this::handleLogin);
        formPanel.add(loginBtn, gbc);

        gbc.gridy++;
        JButton regBtn = new JButton("Don't have an account? Register");
        regBtn.setFont(Theme.FONT_REGULAR);
        regBtn.setForeground(Theme.SECONDARY);
        regBtn.setContentAreaFilled(false);
        regBtn.setBorderPainted(false);
        regBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        regBtn.addActionListener(e -> onGoToRegister.run());
        formPanel.add(regBtn, gbc);

        add(formPanel);
    }

    private void handleLogin(ActionEvent e) {
        String username = userField.getText().trim();
        String password = new String(passField.getPassword());
        
        if (username.isEmpty() || password.isEmpty()) {
            messageLabel.setText("Please enter all fields.");
            return;
        }

        if (authService.login(username, password)) {
            userField.setText("");
            passField.setText("");
            messageLabel.setText("");
            onLoginSuccess.run();
        } else {
            messageLabel.setText("Invalid username or password.");
        }
    }
}
