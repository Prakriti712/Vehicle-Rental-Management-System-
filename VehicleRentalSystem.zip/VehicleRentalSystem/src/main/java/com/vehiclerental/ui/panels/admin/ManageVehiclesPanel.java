package com.vehiclerental.ui.panels.admin;

import com.vehiclerental.model.Vehicle;
import com.vehiclerental.service.VehicleService;
import com.vehiclerental.ui.components.RoundedButton;
import com.vehiclerental.ui.components.StyledTextField;
import com.vehiclerental.ui.components.Theme;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.math.BigDecimal;
import java.util.List;

public class ManageVehiclesPanel extends JPanel {

    private final VehicleService vehicleService;
    private JTable table;
    private DefaultTableModel tableModel;

    public ManageVehiclesPanel(VehicleService vehicleService) {
        this.vehicleService = vehicleService;
        setLayout(new BorderLayout(20, 20));
        setBackground(Theme.BACKGROUND_DARK);
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        initUI();
        loadVehicles();
    }

    private void initUI() {
        // Header
        JLabel header = new JLabel("Manage Vehicles");
        header.setFont(Theme.FONT_TITLE);
        header.setForeground(Theme.TEXT_LIGHT);
        add(header, BorderLayout.NORTH);

        // Table
        String[] columns = {"ID", "Name", "Type", "Rent/Day", "Status"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        table = new JTable(tableModel);
        table.setRowHeight(30);
        table.setFont(Theme.FONT_REGULAR);
        table.getTableHeader().setFont(Theme.FONT_BOLD);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        // Actions Panel
        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        actionPanel.setBackground(Theme.BACKGROUND_DARK);

        RoundedButton addBtn = new RoundedButton("Add Vehicle", Theme.SECONDARY, Theme.SECONDARY.brighter());
        addBtn.setPreferredSize(new Dimension(120, 35));
        addBtn.addActionListener(e -> showAddDialog());
        
        RoundedButton deleteBtn = new RoundedButton("Delete Selected", Theme.DANGER, Theme.DANGER.brighter());
        deleteBtn.setPreferredSize(new Dimension(150, 35));
        deleteBtn.addActionListener(e -> deleteSelected());

        actionPanel.add(addBtn);
        actionPanel.add(deleteBtn);

        add(actionPanel, BorderLayout.SOUTH);
    }

    private void loadVehicles() {
        tableModel.setRowCount(0);
        List<Vehicle> vehicles = vehicleService.getAllVehicles();
        for (Vehicle v : vehicles) {
            tableModel.addRow(new Object[]{
                v.getId(), v.getName(), v.getType(), v.getRentPerDay(), v.getStatus()
            });
        }
    }

    private void showAddDialog() {
        JDialog dialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), "Add Vehicle", true);
        dialog.setLayout(new GridBagLayout());
        dialog.getContentPane().setBackground(Theme.PANEL_DARK);
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0; gbc.gridy = 0;
        dialog.add(createLabel("Name:"), gbc);
        gbc.gridx = 1;
        StyledTextField nameField = new StyledTextField(15);
        dialog.add(nameField, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        dialog.add(createLabel("Type:"), gbc);
        gbc.gridx = 1;
        StyledTextField typeField = new StyledTextField(15);
        dialog.add(typeField, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        dialog.add(createLabel("Rent/Day:"), gbc);
        gbc.gridx = 1;
        StyledTextField rentField = new StyledTextField(15);
        dialog.add(rentField, gbc);

        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
        RoundedButton saveBtn = new RoundedButton("Save", Theme.PRIMARY, Theme.PRIMARY_HOVER);
        saveBtn.addActionListener(e -> {
            try {
                String name = nameField.getText().trim();
                String type = typeField.getText().trim();
                BigDecimal rent = new BigDecimal(rentField.getText().trim());
                if (!name.isEmpty() && !type.isEmpty()) {
                    vehicleService.addVehicle(name, type, rent);
                    loadVehicles();
                    dialog.dispose();
                } else {
                    JOptionPane.showMessageDialog(dialog, "Please fill all fields.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(dialog, "Invalid rent amount.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        dialog.add(saveBtn, gbc);

        dialog.pack();
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    private void deleteSelected() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow >= 0) {
            int id = (int) tableModel.getValueAt(selectedRow, 0);
            int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this vehicle?", "Confirm", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                if (vehicleService.deleteVehicle(id)) {
                    loadVehicles();
                } else {
                    JOptionPane.showMessageDialog(this, "Cannot delete vehicle. It may be part of an active rental.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select a vehicle to delete.", "Information", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private JLabel createLabel(String text) {
        JLabel label = new JLabel(text);
        label.setForeground(Theme.TEXT_LIGHT);
        label.setFont(Theme.FONT_REGULAR);
        return label;
    }
}
