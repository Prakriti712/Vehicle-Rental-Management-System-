package com.vehiclerental.ui.panels.admin;

import com.vehiclerental.model.Rental;
import com.vehiclerental.service.RentalService;
import com.vehiclerental.ui.components.RoundedButton;
import com.vehiclerental.ui.components.Theme;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class AdminRentalsPanel extends JPanel {

    private final RentalService rentalService;
    private JTable table;
    private DefaultTableModel tableModel;

    public AdminRentalsPanel(RentalService rentalService) {
        this.rentalService = rentalService;
        setLayout(new BorderLayout(20, 20));
        setBackground(Theme.BACKGROUND_DARK);
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        initUI();
        loadRentals();
    }

    private void initUI() {
        JLabel header = new JLabel("All Rentals");
        header.setFont(Theme.FONT_TITLE);
        header.setForeground(Theme.TEXT_LIGHT);
        add(header, BorderLayout.NORTH);

        String[] columns = {"Rental ID", "Customer", "Vehicle", "Start Date", "End Date", "Cost", "Status"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        table = new JTable(tableModel);
        table.setRowHeight(30);
        table.setFont(Theme.FONT_REGULAR);
        table.getTableHeader().setFont(Theme.FONT_BOLD);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        actionPanel.setBackground(Theme.BACKGROUND_DARK);

        RoundedButton refreshBtn = new RoundedButton("Refresh", Theme.PRIMARY, Theme.PRIMARY_HOVER);
        refreshBtn.setPreferredSize(new Dimension(120, 35));
        refreshBtn.addActionListener(e -> loadRentals());
        
        RoundedButton returnBtn = new RoundedButton("Mark Returned", Theme.SECONDARY, Theme.SECONDARY.brighter());
        returnBtn.setPreferredSize(new Dimension(150, 35));
        returnBtn.addActionListener(e -> markReturned());

        actionPanel.add(refreshBtn);
        actionPanel.add(returnBtn);

        add(actionPanel, BorderLayout.SOUTH);
    }

    private void loadRentals() {
        tableModel.setRowCount(0);
        List<Rental> rentals = rentalService.getAllRentals();
        for (Rental r : rentals) {
            tableModel.addRow(new Object[]{
                r.getId(), r.getUserName(), r.getVehicleName(), r.getStartDate(), r.getEndDate(), r.getTotalCost(), r.getStatus()
            });
        }
    }

    private void markReturned() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow >= 0) {
            int rentalId = (int) tableModel.getValueAt(selectedRow, 0);
            String status = (String) tableModel.getValueAt(selectedRow, 6);
            if ("COMPLETED".equals(status)) {
                JOptionPane.showMessageDialog(this, "This rental is already completed.", "Information", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            
            if (rentalService.returnVehicle(rentalId)) {
                JOptionPane.showMessageDialog(this, "Vehicle returned successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
                loadRentals();
            } else {
                JOptionPane.showMessageDialog(this, "Failed to update rental status.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select a rental.", "Information", JOptionPane.INFORMATION_MESSAGE);
        }
    }
}
