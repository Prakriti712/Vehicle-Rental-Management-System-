package com.vehiclerental.ui.panels.customer;

import com.vehiclerental.model.Vehicle;
import com.vehiclerental.service.RentalService;
import com.vehiclerental.service.VehicleService;
import com.vehiclerental.ui.components.RoundedButton;
import com.vehiclerental.ui.components.StyledTextField;
import com.vehiclerental.ui.components.Theme;
import com.vehiclerental.util.SessionManager;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.List;

public class BrowseVehiclesPanel extends JPanel {

    private final VehicleService vehicleService;
    private final RentalService rentalService;
    private JTable table;
    private DefaultTableModel tableModel;
    private List<Vehicle> currentVehicles;

    public BrowseVehiclesPanel(VehicleService vehicleService, RentalService rentalService) {
        this.vehicleService = vehicleService;
        this.rentalService = rentalService;
        
        setLayout(new BorderLayout(20, 20));
        setBackground(Theme.BACKGROUND_DARK);
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        initUI();
        loadVehicles();
    }

    private void initUI() {
        JLabel header = new JLabel("Available Vehicles");
        header.setFont(Theme.FONT_TITLE);
        header.setForeground(Theme.TEXT_LIGHT);
        add(header, BorderLayout.NORTH);

        String[] columns = {"ID", "Name", "Type", "Rent/Day"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        table = new JTable(tableModel);
        table.setRowHeight(30);
        table.setFont(Theme.FONT_REGULAR);
        table.getTableHeader().setFont(Theme.FONT_BOLD);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        actionPanel.setBackground(Theme.BACKGROUND_DARK);

        RoundedButton bookBtn = new RoundedButton("Book Selected Vehicle", Theme.SECONDARY, Theme.SECONDARY.brighter());
        bookBtn.setPreferredSize(new Dimension(200, 35));
        bookBtn.addActionListener(e -> showBookingDialog());

        actionPanel.add(bookBtn);
        add(actionPanel, BorderLayout.SOUTH);
    }

    public void loadVehicles() {
        tableModel.setRowCount(0);
        currentVehicles = vehicleService.getAvailableVehicles();
        for (Vehicle v : currentVehicles) {
            tableModel.addRow(new Object[]{
                v.getId(), v.getName(), v.getType(), v.getRentPerDay()
            });
        }
    }

    private void showBookingDialog() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this, "Please select a vehicle to book.", "Information", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        Vehicle selectedVehicle = currentVehicles.get(selectedRow);

        JDialog dialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), "Book Vehicle", true);
        dialog.setLayout(new GridBagLayout());
        dialog.getContentPane().setBackground(Theme.PANEL_DARK);
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0; gbc.gridy = 0;
        dialog.add(createLabel("Start Date (YYYY-MM-DD):"), gbc);
        gbc.gridx = 1;
        StyledTextField startField = new StyledTextField(10);
        startField.setText(LocalDate.now().toString());
        dialog.add(startField, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        dialog.add(createLabel("End Date (YYYY-MM-DD):"), gbc);
        gbc.gridx = 1;
        StyledTextField endField = new StyledTextField(10);
        endField.setText(LocalDate.now().plusDays(1).toString());
        dialog.add(endField, gbc);

        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 2;
        RoundedButton bookBtn = new RoundedButton("Confirm Booking", Theme.PRIMARY, Theme.PRIMARY_HOVER);
        bookBtn.addActionListener(e -> {
            try {
                LocalDate startDate = LocalDate.parse(startField.getText().trim());
                LocalDate endDate = LocalDate.parse(endField.getText().trim());
                
                if (endDate.isBefore(startDate)) {
                    JOptionPane.showMessageDialog(dialog, "End date cannot be before start date.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                int userId = SessionManager.getCurrentUser().getId();
                if (rentalService.bookVehicle(userId, selectedVehicle, startDate, endDate)) {
                    JOptionPane.showMessageDialog(dialog, "Booking successful!", "Success", JOptionPane.INFORMATION_MESSAGE);
                    loadVehicles();
                    dialog.dispose();
                } else {
                    JOptionPane.showMessageDialog(dialog, "Failed to book vehicle.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (DateTimeParseException ex) {
                JOptionPane.showMessageDialog(dialog, "Invalid date format. Use YYYY-MM-DD.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        dialog.add(bookBtn, gbc);

        dialog.pack();
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    private JLabel createLabel(String text) {
        JLabel label = new JLabel(text);
        label.setForeground(Theme.TEXT_LIGHT);
        label.setFont(Theme.FONT_REGULAR);
        return label;
    }
}
